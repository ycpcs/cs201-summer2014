package edu.ycp.cs201.exam1;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LetterCount {
	public static void main(String[] args) throws IOException {
		Scanner keyboard = new Scanner(System.in);
		System.out.printf("What file? ");
		String fileName = keyboard.nextLine();
		
		// TODO: add your code here...
	}
}
