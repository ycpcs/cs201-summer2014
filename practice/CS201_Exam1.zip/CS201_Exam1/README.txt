The LetterCount program should prompt the user to enter
the name of a text file.  It should then read all of the
characters in the file, and count the number of occurrences
of each character that is a letter (A-Z or a-z).  Once it has
counted the letters, it should print the count of each
letter that appeared at least once in the file.

Upper and lower case letters should be treated the same
way (so "a" and "A" both count as the letter A.)

For example, if you run the program on this file (README.txt)
it should produce the following output:

	a: 86
	b: 6
	c: 53
	d: 33
	e: 155
	f: 26
	g: 6
	h: 59
	i: 38
	k: 2
	l: 39
	m: 13
	n: 50
	o: 65
	p: 19
	r: 87
	s: 48
	t: 117
	u: 33
	v: 4
	w: 7
	x: 6
	y: 9
	z: 6

Hints:

- Use a FileReader to read the file.

- The read() method on a FileReader returns an integer character
  code, or -1 if the end of file has been reached.

- If c is the integer character code of an upper case letter,
  then Character.toLowerCase(c) returns the lower case version
  of that letter.  If c is not an upper case letter, then it
  returns c.
  
- If c is a character code, then Character.isLetter(c) returns
  true if c represents a letter (A-Z or a-z).

- Use an array to store the counts, indexed by character code.
  (The character 'z' has the code 122, so you may want to make
  the array have at least 123 elements.)
  
- You do not have to handle exceptions or ensure that the
  FileReader is closed.