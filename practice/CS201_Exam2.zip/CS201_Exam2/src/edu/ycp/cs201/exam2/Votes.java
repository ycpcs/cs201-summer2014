package edu.ycp.cs201.exam2;

import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Votes {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		boolean done = false;
		while (!done) {
			String line = keyboard.nextLine();
			
			// TODO: add your code here
		}
	}
}
