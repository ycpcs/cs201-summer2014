The main method of the Votes class should read lines of input,
where the lines contain alternating names and integers.
Each time a name and an integer is read, the program should
add the integer to the total number of votes cast for the
name.  Note that a name may appear multiple times in the
input.  When the name "quit" is read, the program determines
which name received the most votes and prints a message of the
form

  <<name>> is the winner

where <<name>> is the name of the person who received the most
votes.

Example input:

  Alice
  4
  Bob
  5
  Cormac
  2
  Alice
  3
  Bob
  7
  Delores
  4
  quit

In this input, Alice received 7 votes, Bob received 12 votes,
Cormac received 2 votes, and Delores received 4 votes.  So,
for this input, the winner is Bob, so the program should print
the output

  Bob is the winner

If there is a tie, the program can print any of the names
involved in the tie as the winner.  For extra credit, you may
have the program print all of the names involved in the tie.

Hint: use a Map to store the number of votes for each name:

  Map<String, Integer> votes = new TreeMap<String, Integer>();

Hint: you can convert a String (line of text) to an integer
with the code

  int value = Integer.parseInt(line);

where "line" is a String.

Hint: you can iterate through all of the keys in a map by
calling the keySet() method and using it in a foreach loop:

  for (String key : votes.keySet()) {
