package edu.ycp.cs201.webcrawler;

import junit.framework.TestCase;

public class URITest extends TestCase {
	public void testMakeCanonicalRelativeURI() throws Exception {
		assertEquals("www/index.html", URI.makeCanonical("www/index.html"));
	}
	
	public void testMakeCanonicalRelativeDirectoryURI() throws Exception {
		assertEquals("www/someDir/", URI.makeCanonical("www/someDir/"));
	}
	
	public void testMakeCanonicalGetRidOfCurrentDirectoryUse() throws Exception {
		assertEquals("www/someDir/index.html", URI.makeCanonical("www/someDir/./index.html"));
	}
	
	public void testMakeCanonicalGetRidOfParentDirectoryUse() throws Exception {
		assertEquals("www/index.html", URI.makeCanonical("www/someDir/anotherDir/../../index.html"));
	}
	
	public void testMakeCanonicalComplicatedExample() throws Exception {
		assertEquals("/web/foobie/bletch.html", URI.makeCanonical("/web/foo/bar/../baz/../../blat/./../foobie/bletch.html"));
	}
	
	public void testGetDirectory() throws Exception {
		assertEquals("www/", URI.getDirectory("www/index.html"));
	}
	
	public void testGetDirectory2() throws Exception {
		assertEquals("www/someDir/", URI.getDirectory("www/someDir/index.html"));
	}
	
	public void testGetDirectory3() throws Exception {
		// Special case: the directory of a relative URI consisting of a single
		// non-directory component is considered to be the empty string.
		assertEquals("", URI.getDirectory("index.html"));
	}
	
	public void testGetDirectoryOfAbsoluteURI() throws Exception {
		assertEquals("/www/someDir/", URI.getDirectory("/www/someDir/index.html"));
	}
	
	public void testIsRelative() throws Exception {
		assertTrue(URI.isRelative("foo/bar/baz"));
		assertTrue(URI.isRelative("foo/bar/baz/index.html"));
		assertFalse(URI.isRelative("/index.html"));
		
		// Special case: the empty URI is considered to be relative
		assertTrue(URI.isRelative(""));
	}
	
	public void testGetReferencedURI() throws Exception {
		assertEquals("/foo/bar/baz.html", URI.getReferencedURI("/foo/bar/index.html", "baz.html"));
	}
	
	public void testGetReferencedURI2() throws Exception {
		assertEquals("/foo/bar/thud/baz.html", URI.getReferencedURI("/foo/bar/index.html", "thud/baz.html"));
	}
	
	public void testGetReferencedURI3() throws Exception {
		// Note: the getReferencedURI() method should use the makeCanonical() method
		// to remove references to the current directory (".")
		assertEquals("/foo/bar/baz.html", URI.getReferencedURI("/foo/bar/index.html", "./baz.html"));
	}
	
	public void testGetReferencedURI4() throws Exception {
		// Note: the getReferencedURI() method should use the makeCanonical() method
		// to remove references to the parent directory ("..")
		assertEquals("/foo/baz.html", URI.getReferencedURI("/foo/bar/index.html", "../baz.html"));
	}
	
	public void testGetReferencedURIAbsolute() throws Exception {
		// When a referenced URI is absolute, then it
		// is (obviously) not made relative to the page that
		// references it.
		assertEquals("/foo/bar/baz.html", URI.getReferencedURI("/www/index.html", "/foo/bar/baz.html"));
	}
	
	public void testGetReferencedURIAbsolute2() throws Exception {
		// the getReferencedURI() method should always
		// return a URI in canonical form
		assertEquals("/foo/bar/baz.html", URI.getReferencedURI("/www/index.html", "/foo/bletch/../bar/baz.html"));
	}
}
