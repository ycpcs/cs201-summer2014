package edu.ycp.cs201.gorilla;

/**
 * Instances of this class represent rectangle with a given
 * top left point and given width and height.
 * They can be moved by setting a new top left point,
 * and resized by setting new width/height values.
 * 
 * Important: note that y coordinates increase in the down
 * direction and decrease in the up direction.
 * 
 * @author David Hovemeyer
 */
public class Rectangle {
	// TODO: add fields
	
	/**
	 * Constructor.
	 * 
	 * @param topLeft the top left corner of the rectangle
	 * @param width   the width of the rectangle
	 * @param height  the height of the rectangle
	 */
	public Rectangle(Point topLeft, double width, double height) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Get the top left point of the rectangle.
	 * 
	 * @return the top left point of the rectangle
	 */
	public Point getTopLeft() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the top left point of the rectangle.
	 * 
	 * @param topLeft the (new) top left point of the rectangle
	 */
	public void setTopLeft(Point topLeft) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Get the current width of the rectangle.
	 * 
	 * @return the current width of the rectangle
	 */
	public double getWidth() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the width of the rectangle.
	 * 
	 * @param width the (new) width of the rectangle
	 */
	public void setWidth(double width) {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Get the current height of the rectangle.
	 * 
	 * @return the current height of the rectangle
	 */
	public double getHeight() {
		throw new UnsupportedOperationException("TODO - implement");
	}
	
	/**
	 * Set the height of the rectangle.
	 * 
	 * @param height the (new) height of the rectangle
	 */
	public void setHeight(double height) {
		throw new UnsupportedOperationException("TODO - implement");
	}

	/**
	 * Determine whether the given circle either completely or partially
	 * overlaps this retangle.
	 * 
	 * @param circle  a circle
	 * @return true if the circle completely or partially overlaps the rectangle,
	 *         false if there is no overlap
	 */
	public boolean overlaps(Circle circle) {
		throw new UnsupportedOperationException("TODO - implement");
	}
}
