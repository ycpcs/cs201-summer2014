package edu.ycp.cs201.gorilla;

import static org.junit.Assert.*;
import edu.ycp.cs201.gorilla.Circle;
import edu.ycp.cs201.gorilla.Point;
import edu.ycp.cs201.gorilla.Rectangle;

import org.junit.Before;
import org.junit.Test;

public class RectangleTest {
	// When comparing floating point values for equality, allow
	// a small "fudge factor" to account for the fact that floating
	// point arithmetic is not exact
	private static final double DELTA = 0.00001;
	
	// TODO: fields for test fixture objects
	private Rectangle fiveByFourAtOrigin;
	
	@Before
	public void setUp() {
		// TODO: create test fixture objects
		fiveByFourAtOrigin = new Rectangle(new Point(0.0, 0.0), 5.0, 4.0);
	}
	
	@Test
	public void testGetWidth() {
		assertEquals(5.0, fiveByFourAtOrigin.getWidth(), DELTA);
	}
	
	@Test
	public void testOverlapsEasyCases() throws Exception {
		Circle doesOverlap = new Circle(new Point(3.0, -0.8), 1.0);
		Circle doesNotOverlap = new Circle(new Point(-1.2, 2.0), 1.0);
		
		assertTrue(fiveByFourAtOrigin.overlaps(doesOverlap));
		assertFalse(fiveByFourAtOrigin.overlaps(doesNotOverlap));
	}
	
	public void testOverlapsHardCase() throws Exception {
		Circle doesNotOverlap = new Circle(new Point(-0.9, -0.9), 1.0);
		
		assertFalse(fiveByFourAtOrigin.overlaps(doesNotOverlap));
	}
}
