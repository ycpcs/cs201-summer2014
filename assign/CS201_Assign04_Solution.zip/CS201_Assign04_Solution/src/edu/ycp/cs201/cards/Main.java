package edu.ycp.cs201.cards;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		// an instance of the Game class represents the game state,
		// and has methods to allow moves to be carried out
		Game game = new Game();
		
		// keep going until the game is finished
		while (!game.isFinished()) {
			// print game state (contents of piles)
			printGameState(game);
			
			// see if user wants to move or draw next
			System.out.print("(M)ove a card or (D)raw next card from main deck? ");
			String response = keyboard.next().toLowerCase();
			if (response.equals("d")) {
				// draw next
				game.drawNextCard();
				System.out.println();
				continue;
			}
			if (!response.equals("m")) {
				System.out.println("Invalid response!");
				System.out.println();
				continue;
			}
			
			// move - determine which card or cards are being moved
			System.out.print("Take from which pile (0 for main deck)? ");
			int takePileIndex = keyboard.nextInt();
			CardLocation takeLocation;
			if (takePileIndex == 0) {
				// taking top card from main deck
				takeLocation = new CardLocation(takePileIndex, game.getMainDeck().indexOfTopCard());
			} else {
				// taking one or more cards from a working pile
				System.out.print("  Which card (0 for bottom)? ");
				takeLocation = new CardLocation(takePileIndex, keyboard.nextInt());
			}

			// make sure user's selection is valid
			if (!game.isValidTakeLocation(takeLocation)) {
				System.out.println("Invalid choice!");
				System.out.println();
				continue;
			}

			// Find out which card the player wants to move
			Card takeCard = game.getTakeCard(takeLocation);

			// Ask where card should be moved
			System.out.print("  Place " + takeCard + " where (1-7 for tableau piles, 8-11 for foundation piles ♣,♦,♥,♠)? ");
			int placePile = keyboard.nextInt();

			// make sure overall move is legal
			if (!game.isValidMove(takeLocation, placePile)) {
				System.out.println("Invalid move!");
				System.out.println();
				continue;
			}
			
			// move the card(s)
			game.moveCards(takeLocation, placePile);
			
			System.out.println();
		}
		
		System.out.println("Congratulations! You win!");
	}

	private static void printGameState(Game game) {
		System.out.print("Main deck: [" + (game.getMainDeck().getNumCards()) + "] [");
		if (game.getMainDeck().getNumCards() > 0) {
			System.out.print(game.getMainDeck().getTopCard());
		}
		System.out.println("]");
		System.out.print(  "Finished : ");
		printFinishedPiles(game);
		printWorkingPiles(game);
	}

	private static void printFinishedPiles(Game game) {
		for (int i = 0; i < 4; i++) {
			Deck finishedPile = game.getPile(i + 8);
			if (finishedPile.getNumCards() == 0) {
				System.out.print("[]");
			} else {
				System.out.print("[" + finishedPile.getTopCard() + "]");
			}
			System.out.print(" ");
		}
		System.out.println();
	}
	
	private static void printWorkingPiles(Game game) {
		for (int i = 1; i < 8; i++) {
			Deck workingPile = game.getPile(i);
			System.out.print("Pile " + i + ": ");
			for (int j = 0; j < workingPile.getNumCards(); j++) {
				if (j >= workingPile.getExposeIndex()) {
					System.out.print(workingPile.getCard(j) + " ");
				} else {
					System.out.print("xx ");
				}
			}
			System.out.println();
		}
	}
}
