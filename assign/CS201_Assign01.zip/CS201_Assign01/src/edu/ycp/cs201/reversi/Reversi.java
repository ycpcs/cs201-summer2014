package edu.ycp.cs201.reversi;

import java.util.Scanner;

public class Reversi {
	// Constants defining the game board dimensions.
	public static final int BOARD_WIDTH = 6;
	public static final int BOARD_HEIGHT = 6;
	
	// Constants defining the piece values (to store in the board array).
	public static final int WHITE = 1;
	public static final int BLACK = 2;
	
	// These constants can be used for the "modes" of the
	// traverse function described in the assignment description.
	public static final int CHECK = 1;
	public static final int CAPTURE = 2;
	
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		// TODO: add your code here
	}
}
