package edu.ycp.cs201.gorilla;

public class AngryGorillasModel {
	// Width of the playing field
	public static final double WIDTH = 800.0;
	
	// Height of the playing field
	public static final double HEIGHT = 600.0;
	
	// Width and height of a gorilla (which is assumed to be rectangular)
	public static final double GORILLA_WIDTH = 58.0;
	public static final double GORILLA_HEIGHT = 59.0;
	
	// Radius of a banana (which is assumed to be a circle)
	public static final double BANANA_RADIUS = 10.0;
	
	// Width of a building
	public static final double BUILDING_WIDTH = 80.0;
	
	// TODO: add fields
	
	
	// Constructor
	public AngryGorillasModel() {
		// TODO
	}

	// TODO: add methods

}
