package edu.ycp.cs201.gorilla;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

public class AngryGorillasView extends JPanel {
	private static final long serialVersionUID = 1L;
	
	// Background color (used in the gorilla sprite image, so don't change it)
	private static final Color MIDNIGHT_BLUE = new Color(0, 0, 0xAD);
	
	// Grass color
	private static final Color DARK_GREEN = new Color(0, 127, 0);
	
	// Number of milliseconds between animation timer events
	private static final int TIMER_INTERVAL = 1000/30;

	private AngryGorillasModel model;
	private AngryGorillasController controller;
	
	private BufferedImage gorillaSprite;
	private Font angryBirdsFont;
	private Timer timer;
	
	// Constructor: loads gorilla sprite and the angry birds font,
	// and registers event handlers.  You shouldn't need to modify
	// this.
	public AngryGorillasView() {
		// Source: http://inventwithpython.com/blog/2010/06/25/gorilla-py-a-remake-of-gorilla-bas/ 
		gorillaSprite = loadImage("edu/ycp/cs201/gorilla/res/gorillaSprite.png");
		
		// Source: http://www.dafont.com/angrybirds.font
		angryBirdsFont = loadFont("edu/ycp/cs201/gorilla/res/angrybirds-regular.ttf");

		// Set background and view size
		setBackground(MIDNIGHT_BLUE);
		setPreferredSize(new Dimension((int) AngryGorillasModel.WIDTH, (int) AngryGorillasModel.HEIGHT));
		
		// Register mouse event handlers
		MouseAdapter listener = new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				handleMousePressed(e);
			}

			@Override
			public void mouseDragged(MouseEvent e) {
				handleMouseDragged(e);
			}
			
			@Override
			public void mouseReleased(MouseEvent e) {
				handleMouseReleased(e);
			}
		};
		addMouseListener(listener);
		addMouseMotionListener(listener);

		// Create the animation timer, and register a handler for timer events, but don't start it
		this.timer = new Timer(TIMER_INTERVAL, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				handleTimerTick();
			}
		});
	}
	
	// Start the animation timer.
	public void startTimer() {
		timer.start();
	}
	
	// Load an image from an embedded resource.
	private BufferedImage loadImage(String path) {
		InputStream in = loadResource(path);
		try {
			return ImageIO.read(in);
		} catch (IOException e) {
			throw new IllegalStateException("Couldn't load image " + path, e);
		}
	}
	
	// Load a font from an embedded resource.
	private Font loadFont(String path) {
		InputStream in = loadResource(path);
		try {
			return Font.createFont(Font.TRUETYPE_FONT, in);
		} catch (IOException e) {
			throw new IllegalStateException("Couldn't load font " + path, e);
		} catch (FontFormatException e) {
			throw new IllegalStateException("Couldn't load font " + path, e);
		}
	}

	// Load an embedded resource as an input stream.
	public InputStream loadResource(String path) {
		InputStream in = getClass().getClassLoader().getResourceAsStream(path);
		if (in == null) {
			throw new IllegalStateException("No such resource: " + path);
		}
		return in;
	}

	// Event handler for mouse pressed events
	protected void handleMousePressed(MouseEvent e) {
		// TODO: use controller to handle event and (if necessary) update model
		
		repaint();
	}
	
	// Event handler for mouse dragged events
	protected void handleMouseDragged(MouseEvent e) {
		// TODO: use controller to handle event and (if necessary) update model
		
		repaint();
	}

	// Event handler for mouse released events
	protected void handleMouseReleased(MouseEvent e) {
		// TODO: use controller to handle event and (if necessary) update model
		
		repaint();
	}
	
	// Event handler for animation timer tick events
	protected void handleTimerTick() {
		// TODO: use controller to handle event and (if necessary) update model
		
		repaint();
	}

	// Set the model
	public void setModel(AngryGorillasModel model) {
		this.model = model;
	}
	
	// Set the controller
	public void setController(AngryGorillasController controller) {
		this.controller = controller;
	}
	
	// Handle a paint event by drawing a visualization of the model data
	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g); // paint background
		
		// TODO: render the model

	}
	
	// Main method: you shouldn't need to modify this
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				// Create model and controller objects
				AngryGorillasModel model = new AngryGorillasModel();
				AngryGorillasController controller = new AngryGorillasController();
				
				// Use the controller to initialize the model
				controller.initModel(model);
				
				// Create the view, and connect it to the model and controller objects
				AngryGorillasView view = new AngryGorillasView();
				view.setModel(model);
				view.setController(controller);
				
				// Create a frame to display the view
				JFrame frame = new JFrame();
				frame.setTitle("Angry Gorillas!");
				frame.setContentPane(view);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.pack();
				frame.setVisible(true);
				
				// start the animation timer
				view.startTimer();
			}
		});
	}
}
