package edu.ycp.cs201.optimalchange;

import java.util.ArrayList;
import java.util.List;

public class Change {
	private List<Integer> coins;
	
	public Change() {
		coins = new ArrayList<Integer>();
	}
	
	public void addCoin(int coin) {
		coins.add(coin);
	}
	
	public void addChange(Change change) {
		coins.addAll(change.coins);
	}
	
	public int getNumCoins() {
		return coins.size();
	}
	
	@Override
	public String toString() {
		return coins.toString();
	}
}
