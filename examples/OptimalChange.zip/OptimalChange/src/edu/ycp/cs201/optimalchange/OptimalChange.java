package edu.ycp.cs201.optimalchange;

import java.util.Scanner;

public class OptimalChange {
	private static final int[] DENOM = { 1, 5, 10, 21, 25 };

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.print("How much money: ");
		int amount = keyboard.nextInt();

		Change[] memo = new Change[amount+1];

		// Add base cases for coin denominations
		for (int coin : DENOM) {
			Change c = new Change();
			c.addCoin(coin);
			memo[coin] = c;
		}

		for (int n = 1; n <= amount; n++) {
			if (memo[n] != null) {
				// base case that was already solved
				continue;
			}
			Change best = null;
			// Try adding known denominations to previously
			// computed optimal solutions.
			for (int coin : DENOM) {
				if (n - coin > 0) {
					Change prev = memo[n - coin];
					Change candidate = new Change();
					candidate.addChange(prev);
					candidate.addCoin(coin);
					if (best == null ||
							candidate.getNumCoins() < best.getNumCoins()) {
						best = candidate;
					}
				}
			}
			memo[n] = best;
		}
		
		System.out.println(memo[amount].toString());
	}
}
